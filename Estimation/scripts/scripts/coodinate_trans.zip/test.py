import numpy as np
from scipy.spatial.transform import Rotation as R

def compute_transform_A_to_B(C_to_D_position, C_to_D_quaternion):
    """
    计算A坐标系相对于B坐标系的位姿

    参数:
        C_to_D_position: C相对D的位置 (x, y, z)
        C_to_D_quaternion: C相对D的四元数 (x, y, z, w)

    返回:
        A到B的位置和四元数
    """
    # 1. 定义基本变换
    # A相对于C：绕Z轴旋转90度，原点相同
    R_A_to_C = R.from_euler('z', 90, degrees=True)

    # B相对于D：绕Z轴转270度，再绕X轴转180度，原点相同
    R_B_to_D = R.from_euler('z', 270, degrees=True) * R.from_euler('x', 180, degrees=True)

    # C相对于D：输入参数
    R_C_to_D = R.from_quat(C_to_D_quaternion)

    # 2. 计算旋转部分的变换
    # A相对于D的旋转：R_A_to_D = R_C_to_D * R_A_to_C
    R_A_to_D = R_C_to_D * R_A_to_C

    # B相对于D的旋转：已知为R_B_to_D
    # 我们需要的是A相对于B的旋转：R_A_to_B = R_B_to_D⁻¹ * R_A_to_D
    # 等价于 R_A_to_B = R_D_to_B * R_A_to_D
    R_D_to_B = R_B_to_D.inv()
    R_A_to_B = R_D_to_B * R_A_to_D

    # 3. 计算位置部分的变换
    # 位置向量
    pos_C_to_D = np.array(C_to_D_position)

    # 由于A和C原点相同，所以A相对于D的位置就是C相对于D的位置
    pos_A_to_D = pos_C_to_D

    # 由于B和D原点相同，所以D相对于B的位置是零向量
    # B相对于D的位置也是零向量

    # A相对于B的位置：pos_A_to_B = R_D_to_B * (pos_A_to_D - pos_B_to_D)
    # 由于pos_B_to_D = 0，所以：
    pos_A_to_B = R_D_to_B.apply(pos_A_to_D)

    return pos_A_to_B, R_A_to_B.as_quat()

def main():
    # 测试案例
    print("坐标系变换计算")
    print("=" * 50)

    # 输入参数：C相对D的位姿
    C_to_D_position = [-2, 1, 3]  # (x, y, z)
    C_to_D_quaternion = [1, 0, 0, 0]  # (x, y, z, w)

    print(f"输入:")
    print(f"  C相对于D的位置: {C_to_D_position}")
    print(f"  C相对于D的四元数: {C_to_D_quaternion}")

    # 计算A相对于B的位姿
    A_to_B_position, A_to_B_quaternion = compute_transform_A_to_B(
        C_to_D_position, C_to_D_quaternion
    )

    print(f"\n输出:")
    print(f"  A相对于B的位置: [{A_to_B_position[0]:.6f}, {A_to_B_position[1]:.6f}, {A_to_B_position[2]:.6f}]")
    print(f"  A相对于B的四元数: [{A_to_B_quaternion[0]:.6f}, {A_to_B_quaternion[1]:.6f}, "
          f"{A_to_B_quaternion[2]:.6f}, {A_to_B_quaternion[3]:.6f}]")

    print("\n详细解释:")
    print("=" * 50)

    # 验证变换矩阵
    R_A_to_C = R.from_euler('z', 90, degrees=True)
    R_B_to_D = R.from_euler('z', 270, degrees=True) * R.from_euler('x', 180, degrees=True)
    R_C_to_D = R.from_quat(C_to_D_quaternion)

    # 计算变换矩阵
    R_A_to_D = R_C_to_D * R_A_to_C
    R_D_to_B = R_B_to_D.inv()
    R_A_to_B = R_D_to_B * R_A_to_D

    print(f"R_A_to_C (A到C的旋转):")
    print(R_A_to_C.as_matrix())

    print(f"\nR_B_to_D (B到D的旋转):")
    print(R_B_to_D.as_matrix())

    print(f"\nR_C_to_D (C到D的旋转):")
    print(R_C_to_D.as_matrix())

    print(f"\nR_A_to_B (A到B的旋转):")
    print(R_A_to_B.as_matrix())

    # 计算欧拉角表示
    euler_angles = R_A_to_B.as_euler('xyz', degrees=True)
    print(f"\nA相对于B的欧拉角(度): [{euler_angles[0]:.2f}, {euler_angles[1]:.2f}, {euler_angles[2]:.2f}]")

    # 位置验证
    print(f"\n位置计算验证:")
    print(f"  A在D中的位置: {C_to_D_position}")
    print(f"  B在D中的位置: [0, 0, 0]")
    print(f"  A相对于B的位置: {A_to_B_position}")

if __name__ == "__main__":
    main()
